# ============================================================
# auth.py — PERSON 3's file
# AUTHENTICATION & AUTHORIZATION SYSTEM
# Supports Multiple User Roles: Admin, Charity Manager, Donor
# Includes: Hashing, Session Management, Role-Based Access
# ============================================================

import hashlib
import secrets
import time
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple, Union


class User:
    """Represents a user in the system."""

    def __init__(self, user_id: str, username: str, email: str, role: str, password_hash: str):
        self.user_id = user_id
        self.username = username
        self.email = email
        self.role = role  # "admin", "charity_manager", "donor"
        self.password_hash = password_hash
        self.created_at = datetime.now()
        self.last_login: Optional[datetime] = None
        self.is_active = True
        self.failed_login_attempts = 0
        self.locked_until: Optional[datetime] = None

    def to_dict(self) -> Dict:
        return {
            "user_id": self.user_id,
            "username": self.username,
            "email": self.email,
            "role": self.role,
            "created_at": self.created_at.isoformat(),
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "is_active": self.is_active,
        }


class PasswordManager:
    """Handles password hashing and verification using PBKDF2."""

    HASH_ALGORITHM = "sha256"
    ITERATIONS = 100000

    @staticmethod
    def hash_password(password: str, salt: Optional[str] = None) -> Tuple[str, str]:
        """
        Hash a password using PBKDF2 with salt.
        Returns: (hash, salt)
        """
        if salt is None:
            salt = secrets.token_hex(32)

        hash_obj = hashlib.pbkdf2_hmac(
            PasswordManager.HASH_ALGORITHM,
            password.encode('utf-8'),
            salt.encode('utf-8'),
            PasswordManager.ITERATIONS
        )
        password_hash = hash_obj.hex()
        return f"{password_hash}${salt}", salt

    @staticmethod
    def verify_password(stored_hash: str, provided_password: str) -> bool:
        """Verify a provided password against a stored hash."""
        try:
            password_hash, salt = stored_hash.split('$')
            computed_hash, _ = PasswordManager.hash_password(provided_password, salt)
            return computed_hash == stored_hash
        except ValueError:
            return False


class Session:
    """Represents an authenticated user session."""

    def __init__(self, session_id: str, user: User, expiry_minutes: int = 60):
        self.session_id = session_id
        self.user = user
        self.created_at = datetime.now()
        self.expires_at = self.created_at + timedelta(minutes=expiry_minutes)
        self.last_activity = self.created_at
        self.ip_address: Optional[str] = None
        self.user_agent: Optional[str] = None

    def is_valid(self) -> bool:
        """Check if session is still valid (not expired)."""
        return datetime.now() < self.expires_at

    def is_expired(self) -> bool:
        """Check if session has expired."""
        return datetime.now() >= self.expires_at

    def refresh(self, expiry_minutes: int = 60):
        """Extend session expiry time."""
        self.expires_at = datetime.now() + timedelta(minutes=expiry_minutes)
        self.last_activity = datetime.now()

    def to_dict(self) -> Dict:
        return {
            "session_id": self.session_id,
            "user": self.user.to_dict(),
            "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat(),
            "is_valid": self.is_valid(),
        }


class AuthenticationManager:
    """
    Manages user authentication, authorization, and session management.
    Supports multiple roles with different permissions.
    """

    # Role-based permissions
    PERMISSIONS = {
        "admin": [
            "view_dashboard",
            "manage_charities",
            "verify_beneficiaries",
            "release_funds",
            "view_users",
            "manage_users",
            "view_audit_log",
        ],
        "charity_manager": [
            "view_dashboard",
            "view_charities",
            "add_beneficiaries",
            "view_beneficiaries",
            "view_donations",
        ],
        "donor": [
            "view_charities",
            "make_donation",
            "track_donation",
        ],
    }

    def __init__(self):
        self.users: Dict[str, User] = {}
        self.sessions: Dict[str, Session] = {}
        self.audit_log: list = []
        self._initialize_default_users()

    def _initialize_default_users(self):
        """Create default admin and test users."""
        # Super Admin
        admin_hash, _ = PasswordManager.hash_password("Admin@123")
        admin = User("U001", "Admin", "admin@charity.org", "admin", admin_hash)
        self.users["U001"] = admin

        # Charity Manager
        mgr_hash, _ = PasswordManager.hash_password("Manager@123")
        manager = User("U002", "Charity_Manager", "manager@charity.org", "charity_manager", mgr_hash)
        self.users["U002"] = manager

    def register_user(self, username: str, email: str, password: str, role: str = "donor") -> Tuple[bool, str, Optional[User]]:
        """
        Register a new user.
        Returns: (success: bool, message: str, user: Optional[User])
        """
        # Validate role
        if role not in self.PERMISSIONS:
            return False, f"Invalid role: {role}", None

        # Check if username exists
        if any(u.username == username for u in self.users.values()):
            return False, "Username already exists", None

        # Check if email exists
        if any(u.email == email for u in self.users.values()):
            return False, "Email already registered", None

        # Hash password
        password_hash, _ = PasswordManager.hash_password(password)

        # Generate user ID
        user_id = f"U{len(self.users) + 1:03d}"

        # Create user
        new_user = User(user_id, username, email, role, password_hash)
        self.users[user_id] = new_user

        # Log audit event
        self._log_audit("USER_REGISTERED", f"New {role} registered: {username}")

        return True, "User registered successfully", new_user

    def login(self, username: str, password: str, ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> Tuple[bool, str, Optional[Session]]:
        """
        Authenticate user and create session.
        Returns: (success: bool, message: str, session: Optional[Session])
        """
        # Find user by username
        user = None
        for u in self.users.values():
            if u.username == username:
                user = u
                break

        if not user:
            self._log_audit("LOGIN_FAILED", f"Unknown user: {username}")
            return False, "Invalid username or password", None

        # Check if account is locked
        if user.locked_until and datetime.now() < user.locked_until:
            remaining = (user.locked_until - datetime.now()).total_seconds() / 60
            return False, f"Account locked. Try again in {remaining:.0f} minutes", None

        # Verify password
        if not PasswordManager.verify_password(user.password_hash, password):
            user.failed_login_attempts += 1

            # Lock account after 5 failed attempts
            if user.failed_login_attempts >= 5:
                user.locked_until = datetime.now() + timedelta(minutes=30)
                self._log_audit("ACCOUNT_LOCKED", f"Account locked after failed attempts: {username}")
                return False, "Too many failed attempts. Account locked for 30 minutes", None

            self._log_audit("LOGIN_FAILED", f"Wrong password: {username}")
            return False, "Invalid username or password", None

        # Check if user is active
        if not user.is_active:
            self._log_audit("LOGIN_FAILED", f"Inactive account: {username}")
            return False, "Your account has been deactivated", None

        # Reset failed login attempts
        user.failed_login_attempts = 0
        user.locked_until = None

        # Create session
        session_id = secrets.token_urlsafe(32)
        session = Session(session_id, user)
        session.ip_address = ip_address
        session.user_agent = user_agent
        self.sessions[session_id] = session

        # Update last login
        user.last_login = datetime.now()

        self._log_audit("LOGIN_SUCCESS", f"User logged in: {username}")

        return True, "Login successful", session

    def logout(self, session_id: str) -> Tuple[bool, str]:
        """
        Logout a user (invalidate session).
        Returns: (success: bool, message: str)
        """
        if session_id in self.sessions:
            session = self.sessions[session_id]
            self._log_audit("LOGOUT", f"User logged out: {session.user.username}")
            del self.sessions[session_id]
            return True, "Logged out successfully"

        return False, "Invalid session"

    def verify_session(self, session_id: str) -> Tuple[bool, Optional[User]]:
        """
        Verify if a session is valid and return the user.
        Returns: (is_valid: bool, user: Optional[User])
        """
        if session_id not in self.sessions:
            return False, None

        session = self.sessions[session_id]

        if not session.is_valid():
            del self.sessions[session_id]
            return False, None

        # Refresh session
        session.refresh()
        return True, session.user

    def has_permission(self, user: User, permission: str) -> bool:
        """Check if a user has a specific permission."""
        user_permissions = self.PERMISSIONS.get(user.role, [])
        return permission in user_permissions

    def can_access_resource(self, user: User, resource_type: str, resource_id: Optional[str] = None) -> bool:
        """
        Check if user can access a specific resource.
        Returns: bool
        """
        # Admin can access everything
        if user.role == "admin":
            return True

        # Charity managers can access charity-related resources
        if user.role == "charity_manager" and resource_type == "charity":
            return True

        # Donors can access public resources
        if user.role == "donor" and resource_type in ["charities", "donations"]:
            return True

        return False

    def change_password(self, username: str, old_password: str, new_password: str) -> Tuple[bool, str]:
        """
        Change a user's password.
        Returns: (success: bool, message: str)
        """
        # Find user
        user = None
        for u in self.users.values():
            if u.username == username:
                user = u
                break

        if not user:
            return False, "User not found"

        # Verify old password
        if not PasswordManager.verify_password(user.password_hash, old_password):
            return False, "Old password is incorrect"

        # Hash new password
        new_hash, _ = PasswordManager.hash_password(new_password)
        user.password_hash = new_hash

        self._log_audit("PASSWORD_CHANGED", f"Password changed: {username}")
        return True, "Password changed successfully"

    def _log_audit(self, action: str, details: str):
        """Log an audit event."""
        self.audit_log.append({
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "details": details,
        })

    def get_audit_log(self, limit: int = 100) -> list:
        """Get recent audit log entries."""
        return self.audit_log[-limit:]

    def get_all_users(self) -> Dict[str, Dict]:
        """Get all users (admin only)."""
        return {uid: u.to_dict() for uid, u in self.users.items()}

    def deactivate_user(self, user_id: str) -> Tuple[bool, str]:
        """Deactivate a user account (admin only)."""
        if user_id in self.users:
            self.users[user_id].is_active = False
            self._log_audit("USER_DEACTIVATED", f"User deactivated: {self.users[user_id].username}")
            return True, "User deactivated"
        return False, "User not found"


# Global authentication manager instance
auth_manager = AuthenticationManager()
