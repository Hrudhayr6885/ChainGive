# ============================================================
# contract_logic.py — PERSON 1's file (Business Logic Layer)
# Smart Contract Logic: Charities, Beneficiaries, Fund Management
# Bridges Blockchain with Application
# ============================================================

import json
import os
from datetime import datetime
from .blockchain import Blockchain
from .consensus import consensus_engine


class CharityManagementContract:
    """
    Smart Contract for Charity Operations.
    Manages charities, beneficiaries, donations, and fund release.
    """

    # Default charities and beneficiaries
    DEFAULT_CHARITIES = [
        {"id": "C001", "name": "Feed the Hungry", "description": "Providing meals to homeless", "verified": True},
        {"id": "C002", "name": "Education for All", "description": "Supporting education initiatives", "verified": True},
        {"id": "C003", "name": "Health Aid Fund", "description": "Healthcare and medical support", "verified": True},
    ]

    DEFAULT_BENEFICIARIES = [
        {"id": "B001", "name": "Ananya Sharma", "charity_id": "C001", "verified": True},
        {"id": "B002", "name": "Ravi Kumar", "charity_id": "C002", "verified": True},
        {"id": "B003", "name": "Priya Nair", "charity_id": "C003", "verified": False},
    ]

    def __init__(self, data_file: str = "data.json"):
        self.blockchain = Blockchain()
        self.data_file = data_file
        self.charities = {}
        self.beneficiaries = {}
        self.donation_count = 0
        self.fraud_flags = []

        # Initialize default data
        for charity in self.DEFAULT_CHARITIES:
            self.charities[charity["id"]] = {
                **charity,
                "balance": 0.0,
                "created_at": datetime.now().isoformat(),
                "total_received": 0.0,
            }

        for beneficiary in self.DEFAULT_BENEFICIARIES:
            self.beneficiaries[beneficiary["id"]] = {
                **beneficiary,
                "funds_received": 0.0,
                "transaction_history": [],
            }

        # Load existing data if available
        self.load_data()

        # Register charities as validators in consensus engine
        for charity_id, charity_data in self.charities.items():
            consensus_engine.register_validator(charity_id, charity_data["balance"])

    def save_data(self):
        """
        Persist blockchain and contract state to data.json.
        Used for data recovery after server restart.
        """
        data = {
            "blockchain": self.blockchain.to_dict(),
            "charities": self.charities,
            "beneficiaries": self.beneficiaries,
            "donation_count": self.donation_count,
            "fraud_flags": self.fraud_flags,
            "last_saved": datetime.now().isoformat(),
        }

        with open(self.data_file, "w") as f:
            json.dump(data, f, indent=2)

    def load_data(self):
        """
        Load blockchain and contract state from data.json.
        Called on server startup.
        """
        if not os.path.exists(self.data_file):
            return

        try:
            with open(self.data_file, "r") as f:
                data = json.load(f)

            # Restore blockchain
            if "blockchain" in data:
                self.blockchain.load_from_list(data["blockchain"])

            # Restore contract state
            if "charities" in data:
                self.charities = data["charities"]
                # Ensure all required fields exist in charities
                for charity_id in self.charities:
                    if "balance" not in self.charities[charity_id]:
                        self.charities[charity_id]["balance"] = 0.0
                    if "total_received" not in self.charities[charity_id]:
                        self.charities[charity_id]["total_received"] = 0.0
                    if "created_at" not in self.charities[charity_id]:
                        self.charities[charity_id]["created_at"] = datetime.now().isoformat()
                        
            if "beneficiaries" in data:
                self.beneficiaries = data["beneficiaries"]
                # Ensure all required fields exist in beneficiaries
                for beneficiary_id in self.beneficiaries:
                    if "funds_received" not in self.beneficiaries[beneficiary_id]:
                        self.beneficiaries[beneficiary_id]["funds_received"] = 0.0
                    if "transaction_history" not in self.beneficiaries[beneficiary_id]:
                        self.beneficiaries[beneficiary_id]["transaction_history"] = []
                        
            if "donation_count" in data:
                self.donation_count = data["donation_count"]
            if "fraud_flags" in data:
                self.fraud_flags = data["fraud_flags"]

        except Exception as e:
            print(f"⚠️ Error loading data: {e}")

    # ── DONATION LOGIC ─────────────────────────────────────────

    def donate(self, donor_name: str, charity_id: str, amount: float, message: str = "") -> dict:
        """
        Record a donation on the blockchain.
        Includes fraud detection and consensus validation.
        """
        # Validate inputs
        if charity_id not in self.charities:
            return {"success": False, "error": "Charity not found"}

        if amount <= 0:
            return {"success": False, "error": "Amount must be positive"}

        if len(donor_name.strip()) == 0:
            return {"success": False, "error": "Donor name is required"}

        # Fraud detection
        fraud_check = self._check_fraud(donor_name, amount)
        if fraud_check["flagged"]:
            self.fraud_flags.append(fraud_check)
            if fraud_check["severity"] == "high":
                return {"success": False, "error": f"Donation flagged: {fraud_check['reason']}"}

        # Create transaction
        transaction = {
            "type": "DONATION",
            "donor_name": donor_name,
            "charity_id": charity_id,
            "charity_name": self.charities[charity_id]["name"],
            "amount": amount,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "status": "CONFIRMED",
        }

        try:
            # Add to blockchain (consensus engine validates)
            tx_hash = self.blockchain.add_transaction(transaction)

            # Update balances
            self.charities[charity_id]["balance"] += amount
            self.charities[charity_id]["total_received"] += amount
            self.donation_count += 1

            # Update validator stake
            consensus_engine.update_validator_stake(
                charity_id,
                self.charities[charity_id]["balance"]
            )

            # Save state
            self.save_data()

            return {
                "success": True,
                "tx_hash": tx_hash,
                "message": "Donation recorded on blockchain",
            }

        except Exception as e:
            return {"success": False, "error": f"Blockchain error: {str(e)}"}

    def _check_fraud(self, donor_name: str, amount: float) -> dict:
        """
        Fraud detection system.
        Flags suspicious donations based on patterns.
        """
        fraud_indicators = {
            "flagged": False,
            "severity": "low",
            "reason": "",
        }

        # Check 1: Unusually large donations
        if amount > 10000:
            fraud_indicators["flagged"] = True
            fraud_indicators["severity"] = "medium"
            fraud_indicators["reason"] = "Unusually large donation amount"

        # Check 2: Repeated donations from same donor (rate limiting)
        recent_donations = [
            tx for tx in self.blockchain.get_all_transactions()
            if tx.get("donor_name") == donor_name and tx.get("type") == "DONATION"
        ]

        if len(recent_donations) > 100:
            fraud_indicators["flagged"] = True
            fraud_indicators["severity"] = "medium"
            fraud_indicators["reason"] = "Excessive donations from same donor"

        # Check 3: Suspicious names (too short or contains numbers)
        if len(donor_name) < 2 or donor_name.isdigit():
            fraud_indicators["flagged"] = True
            fraud_indicators["severity"] = "low"
            fraud_indicators["reason"] = "Suspicious donor name"

        return fraud_indicators

    # ── FUND RELEASE LOGIC ─────────────────────────────────────

    def release_funds(self, charity_id: str, beneficiary_id: str, amount: float) -> dict:
        """
        Release funds from charity to beneficiary.
        Only admin can call this. Records as blockchain transaction.
        """
        # Validate inputs
        if charity_id not in self.charities:
            return {"success": False, "error": "Charity not found"}

        if beneficiary_id not in self.beneficiaries:
            return {"success": False, "error": "Beneficiary not found"}

        if amount <= 0:
            return {"success": False, "error": "Amount must be positive"}

        # Check balance
        if self.charities[charity_id]["balance"] < amount:
            return {"success": False, "error": f"Insufficient balance. Available: ${self.charities[charity_id]['balance']:.2f}"}

        # Check beneficiary is verified
        if not self.beneficiaries[beneficiary_id]["verified"]:
            return {"success": False, "error": "Beneficiary not verified"}

        # Create transaction
        transaction = {
            "type": "FUND_RELEASE",
            "charity_id": charity_id,
            "charity_name": self.charities[charity_id]["name"],
            "beneficiary_id": beneficiary_id,
            "beneficiary_name": self.beneficiaries[beneficiary_id]["name"],
            "amount": amount,
            "timestamp": datetime.now().isoformat(),
            "status": "COMPLETED",
        }

        try:
            # Add to blockchain
            tx_hash = self.blockchain.add_transaction(transaction)

            # Update balances
            self.charities[charity_id]["balance"] -= amount
            self.beneficiaries[beneficiary_id]["funds_received"] += amount
            self.beneficiaries[beneficiary_id]["transaction_history"].append(tx_hash)

            # Save state
            self.save_data()

            return {
                "success": True,
                "tx_hash": tx_hash,
                "message": f"Funds released to {self.beneficiaries[beneficiary_id]['name']}",
            }

        except Exception as e:
            return {"success": False, "error": f"Blockchain error: {str(e)}"}

    # ── BENEFICIARY MANAGEMENT ─────────────────────────────────

    def verify_beneficiary(self, beneficiary_id: str) -> dict:
        """
        Verify a beneficiary (admin function).
        Records verification on blockchain.
        """
        if beneficiary_id not in self.beneficiaries:
            return {"success": False, "error": "Beneficiary not found"}

        if self.beneficiaries[beneficiary_id]["verified"]:
            return {"success": False, "error": "Beneficiary already verified"}

        # Create transaction
        transaction = {
            "type": "BENEFICIARY_VERIFIED",
            "beneficiary_id": beneficiary_id,
            "beneficiary_name": self.beneficiaries[beneficiary_id]["name"],
            "timestamp": datetime.now().isoformat(),
            "status": "COMPLETED",
        }

        try:
            tx_hash = self.blockchain.add_transaction(transaction)
            self.beneficiaries[beneficiary_id]["verified"] = True
            self.save_data()

            return {
                "success": True,
                "tx_hash": tx_hash,
                "message": "Beneficiary verified",
            }
        except Exception as e:
            return {"success": False, "error": f"Error: {str(e)}"}

    def add_beneficiary(self, name: str, charity_id: str) -> dict:
        """
        Add a new beneficiary (pending verification).
        """
        if charity_id not in self.charities:
            return {"success": False, "error": "Charity not found"}

        if len(name.strip()) == 0:
            return {"success": False, "error": "Name is required"}

        # Generate beneficiary ID
        beneficiary_id = f"B{len(self.beneficiaries) + 1:03d}"

        new_beneficiary = {
            "id": beneficiary_id,
            "name": name,
            "charity_id": charity_id,
            "verified": False,
            "funds_received": 0.0,
            "transaction_history": [],
        }

        self.beneficiaries[beneficiary_id] = new_beneficiary

        # Create transaction
        transaction = {
            "type": "BENEFICIARY_ADDED",
            "beneficiary_id": beneficiary_id,
            "name": name,
            "charity_id": charity_id,
            "timestamp": datetime.now().isoformat(),
            "status": "PENDING_VERIFICATION",
        }

        try:
            tx_hash = self.blockchain.add_transaction(transaction)
            self.save_data()

            return {
                "success": True,
                "beneficiary_id": beneficiary_id,
                "tx_hash": tx_hash,
                "message": "Beneficiary added (pending verification)",
            }
        except Exception as e:
            return {"success": False, "error": f"Error: {str(e)}"}

    # ── GETTERS FOR DISPLAY ────────────────────────────────────

    def get_charities(self) -> dict:
        """Get all charities."""
        return self.charities

    def get_beneficiaries(self) -> dict:
        """Get all beneficiaries."""
        return self.beneficiaries

    def get_stats(self) -> dict:
        """Get overall statistics."""
        total_donated = sum(c["total_received"] for c in self.charities.values())
        total_balance = sum(c["balance"] for c in self.charities.values())
        total_released = total_donated - total_balance
        chain_health = self.blockchain.get_chain_health()

        return {
            "total_charities": len(self.charities),
            "total_beneficiaries": len(self.beneficiaries),
            "total_donations": self.donation_count,
            "total_donated": total_donated,
            "total_balance": total_balance,
            "total_released": total_released,
            "blockchain_blocks": chain_health["total_blocks"],
            "blockchain_validity": chain_health["is_valid"],
            "chain_integrity": f"{chain_health['chain_integrity']:.1f}%",
            "chain_valid": chain_health["is_valid"],
            "chain_length": chain_health["total_blocks"],
        }


# Global contract instance
contract = CharityManagementContract()
