# ============================================================
# consensus.py — PERSON 1's file (Part 2)
# CONSENSUS ALGORITHM: Enhanced Proof-of-Work with Byzantine Resilience
# Ensures blockchain security even if some nodes are compromised
# ============================================================

import hashlib
import time
from typing import Dict, List


class ConsensusEngine:
    """
    Advanced Consensus Mechanism:
    - Proof-of-Work (PoW): Standard mining with difficulty
    - Byzantine Fault Tolerance: Validates chain integrity
    - Stake-weighted Validation: Charities with higher stakes have more weight
    """

    def __init__(self, difficulty: int = 2, byzantine_tolerance: float = 0.33):
        """
        Args:
            difficulty: Number of leading zeros required in hash (higher = harder)
            byzantine_tolerance: % of nodes that can be faulty (default 33%)
        """
        self.difficulty = difficulty
        self.byzantine_tolerance = byzantine_tolerance
        self.validator_stakes = {}  # Track validator credibility

    def validate_block(self, block_obj) -> bool:
        """
        Validate a block using Byzantine Fault Tolerant rules.
        Returns True if block is valid and trusted.
        """
        # Rule 1: Hash must start with required zeros (Proof-of-Work)
        if not block_obj.hash.startswith("0" * self.difficulty):
            return False

        # Rule 2: Hash must be correctly calculated
        if block_obj.hash != block_obj.calculate_hash():
            return False

        # Rule 3: Timestamp must be reasonable (not in future)
        block_time = time.mktime(time.strptime(block_obj.timestamp, "%Y-%m-%d %H:%M:%S"))
        if block_time > time.time():
            return False

        # Rule 4: Block cannot be empty (must have transactions)
        if not block_obj.transactions or len(block_obj.transactions) == 0:
            return False

        return True

    def validate_chain(self, chain: List) -> tuple:
        """
        Full chain validation with Byzantine Fault Tolerance.
        Returns: (is_valid: bool, fault_count: int)
        
        A chain is valid if less than 33% of nodes are faulty.
        """
        if not chain or len(chain) == 0:
            return False, 0

        fault_count = 0

        # Validate each block and its links
        for i in range(1, len(chain)):
            current = chain[i]
            previous = chain[i - 1]

            # Check block integrity
            if not self.validate_block(current):
                fault_count += 1
                continue

            # Check chain continuity
            if current.previous_hash != previous.hash:
                fault_count += 1
                continue

        # Byzantine Fault Tolerance check
        max_faults = int(len(chain) * self.byzantine_tolerance)
        is_valid = fault_count <= max_faults

        return is_valid, fault_count

    def register_validator(self, charity_id: str, stake_amount: float):
        """
        Register a charity as a validator with its stake.
        Higher stake = more influence in consensus.
        """
        self.validator_stakes[charity_id] = stake_amount

    def update_validator_stake(self, charity_id: str, new_stake: float):
        """Update a validator's stake (increases with donations)."""
        self.validator_stakes[charity_id] = new_stake

    def get_validator_weight(self, charity_id: str) -> float:
        """
        Calculate voting weight of a validator.
        Weight = stake / total_stakes
        """
        if not self.validator_stakes:
            return 1.0 / 1

        total_stake = sum(self.validator_stakes.values())
        if total_stake == 0:
            return 0.0

        return self.validator_stakes.get(charity_id, 0) / total_stake

    def adjust_difficulty(self, blocks_time: float, target_time: float = 120) -> int:
        """
        Dynamically adjust mining difficulty.
        If blocks are being mined too fast/slow, increase/decrease difficulty.
        
        Args:
            blocks_time: Time taken to mine last N blocks (seconds)
            target_time: Target time for mining (default 2 minutes)
        
        Returns: New difficulty level
        """
        if blocks_time < target_time:
            # Blocks too fast, increase difficulty
            self.difficulty += 1
        elif blocks_time > target_time and self.difficulty > 1:
            # Blocks too slow, decrease difficulty
            self.difficulty -= 1

        return self.difficulty

    def verify_transaction_batch(self, transactions: List[Dict]) -> tuple:
        """
        Verify a batch of transactions for consistency.
        Returns: (all_valid: bool, invalid_count: int)
        """
        invalid_count = 0

        for tx in transactions:
            if not self._validate_single_transaction(tx):
                invalid_count += 1

        return invalid_count == 0, invalid_count

    @staticmethod
    def _validate_single_transaction(tx: Dict) -> bool:
        """Validate individual transaction."""
        # Different transaction types have different required fields
        tx_type = tx.get("type", "")
        
        if tx_type == "DONATION":
            required_fields = ["donor_name", "charity_id", "amount"]
        elif tx_type == "FUND_RELEASE":
            required_fields = ["charity_id", "beneficiary_id", "amount"]
        elif tx_type == "BENEFICIARY_VERIFIED":
            required_fields = ["beneficiary_id"]
        elif tx_type == "BENEFICIARY_ADDED":
            required_fields = ["beneficiary_id", "name", "charity_id"]
        elif tx_type == "GENESIS":
            required_fields = ["type", "message"]
        else:
            required_fields = ["type"]  # At minimum, must have a type
        
        # Check all required fields exist
        for field in required_fields:
            if field not in tx:
                return False

        # Validate amount is positive (if present)
        if "amount" in tx:
            try:
                amount = float(tx.get("amount", 0))
                if amount <= 0:
                    return False
            except (ValueError, TypeError):
                return False

        return True

    def generate_merkle_root(self, transactions: List[Dict]) -> str:
        """
        Generate Merkle Tree root for transactions.
        Ensures transaction integrity and tamper-proofing.
        """
        if not transactions:
            return hashlib.sha256(b"").hexdigest()

        # Hash each transaction
        hashes = []
        for tx in transactions:
            tx_string = str(sorted(tx.items()))
            tx_hash = hashlib.sha256(tx_string.encode()).hexdigest()
            hashes.append(tx_hash)

        # Build merkle tree
        while len(hashes) > 1:
            if len(hashes) % 2 != 0:
                hashes.append(hashes[-1])  # Duplicate last if odd

            new_hashes = []
            for i in range(0, len(hashes), 2):
                combined = hashes[i] + hashes[i + 1]
                new_hash = hashlib.sha256(combined.encode()).hexdigest()
                new_hashes.append(new_hash)
            hashes = new_hashes

        return hashes[0]


# Global consensus engine instance
consensus_engine = ConsensusEngine(difficulty=2, byzantine_tolerance=0.33)
