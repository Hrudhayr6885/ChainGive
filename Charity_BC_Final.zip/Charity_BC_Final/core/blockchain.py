# ============================================================
# blockchain.py — PERSON 1's file (Part 1)
# Handles the core blockchain: blocks, hashing, chain validity
# WITH: save/load support + Consensus Engine Integration
# ============================================================

import hashlib
import json
import time
from .consensus import consensus_engine


class Block:
    """A single block in the chain. Stores a list of transactions."""

    def __init__(self, index, transactions, previous_hash,
                 timestamp=None, nonce=0, hash=None):
        self.index = index
        self.timestamp = timestamp or time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.hash = hash or self.calculate_hash()

    def calculate_hash(self):
        """SHA-256 hash of the block contents."""
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
        }, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

    def mine_block(self, difficulty=2):
        """
        Proof-of-Work: keep changing nonce until hash starts with
        difficulty number of zeros. Makes the chain tamper-proof.
        """
        target = "0" * difficulty
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()

    @classmethod
    def from_dict(cls, data: dict):
        """
        Reconstruct a Block from a saved dictionary (from data.json).
        Skips mining — uses the saved hash directly.
        """
        return cls(
            index=data["index"],
            transactions=data["transactions"],
            previous_hash=data["previous_hash"],
            timestamp=data["timestamp"],
            nonce=data["nonce"],
            hash=data["hash"],
        )


class Blockchain:
    """
    The full chain with Consensus Integration.
    Uses Proof-of-Work + Byzantine Fault Tolerance for security.
    """

    def __init__(self):
        self.difficulty = 2
        self.consensus_engine = consensus_engine
        self.chain = [self._create_genesis_block()]

    def _create_genesis_block(self):
        """Create the first block (genesis block)."""
        genesis = Block(0, [{"type": "GENESIS", "message": "Charity Chain Started"}], "0")
        genesis.mine_block(self.difficulty)
        return genesis

    def load_from_list(self, chain_data: list):
        """
        Replaces the current chain with blocks rebuilt from saved data.
        Called on startup when data.json exists.
        """
        self.chain = [Block.from_dict(b) for b in chain_data]

    def add_transaction(self, transaction: dict) -> str:
        """
        Mines a new block containing transaction and appends it.
        Uses consensus engine for validation.
        Returns the new block's hash (the donor's tracking ID).
        """
        # Validate transaction before adding
        if not self.consensus_engine._validate_single_transaction(transaction):
            raise ValueError("Invalid transaction format")

        new_block = Block(
            index=len(self.chain),
            transactions=[transaction],
            previous_hash=self.get_latest_block().hash,
        )
        new_block.mine_block(self.difficulty)

        # Validate block before appending
        if not self.consensus_engine.validate_block(new_block):
            raise ValueError("Block validation failed")

        self.chain.append(new_block)
        return new_block.hash

    def get_latest_block(self):
        """Get the most recent block."""
        return self.chain[-1]

    def is_chain_valid(self) -> bool:
        """
        Check chain validity using Byzantine Fault Tolerant consensus.
        Returns True if chain is valid and trustworthy.
        """
        is_valid, fault_count = self.consensus_engine.validate_chain(self.chain)
        return is_valid

    def get_chain_health(self) -> dict:
        """
        Get detailed health metrics of the chain.
        Useful for monitoring blockchain integrity.
        """
        is_valid, fault_count = self.consensus_engine.validate_chain(self.chain)

        return {
            "is_valid": is_valid,
            "total_blocks": len(self.chain),
            "fault_blocks": fault_count,
            "chain_integrity": (len(self.chain) - fault_count) / len(self.chain) * 100 if self.chain else 0,
            "difficulty": self.difficulty,
        }

    def get_all_transactions(self) -> list:
        """Return every transaction across all blocks (skips genesis)."""
        txs = []
        for block in self.chain[1:]:
            for tx in block.transactions:
                txs.append({
                    **tx,
                    "block_index": block.index,
                    "block_hash": block.hash,
                    "timestamp": block.timestamp,
                })
        return txs

    def find_transaction(self, tx_hash: str):
        """Look up a specific transaction by block hash (the tracking ID)."""
        for block in self.chain[1:]:
            if block.hash == tx_hash:
                tx = block.transactions[0] if block.transactions else {}
                return {
                    **tx,
                    "block_index": block.index,
                    "block_hash": block.hash,
                    "timestamp": block.timestamp,
                }
        return None

    def to_dict(self) -> list:
        """Serialise the entire chain — used for display and for saving."""
        result = []
        for block in self.chain:
            result.append({
                "index": block.index,
                "timestamp": block.timestamp,
                "transactions": block.transactions,
                "previous_hash": block.previous_hash,
                "hash": block.hash,
                "nonce": block.nonce,
            })
        return result
