# ============================================================
# web/app.py — PERSON 2's file
# Flask Web Server: Connects Smart Contract to GUI
# WITH: Enhanced Authentication & Role-Based Access Control
# ============================================================

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contract_logic import contract
from core.auth import auth_manager
from web.decorators import login_required, admin_required, charity_manager_required, get_current_user

# ── FLASK APP SETUP ───────────────────────────────────────────
app = Flask(__name__)
app.secret_key = "charity_blockchain_secret_2024"

# Configure templates folder
app.template_folder = os.path.join(os.path.dirname(__file__), "..", "templates")


# ── BEFORE REQUEST: Inject current user ───────────────────────
@app.before_request
def inject_user():
    """Make current user available in all templates."""
    current_user = get_current_user()
    if current_user:
        session["current_user"] = {
            "username": current_user.username,
            "role": current_user.role,
            "email": current_user.email,
        }
    else:
        session.pop("current_user", None)


# ── PUBLIC ROUTES ─────────────────────────────────────────────

@app.route("/")
def index():
    """Home page - public."""
    stats = contract.get_stats()
    charities = contract.get_charities()
    recent_txs = contract.blockchain.get_all_transactions()[-5:][::-1]
    current_user = get_current_user()
    chain_health = contract.blockchain.get_chain_health()

    return render_template(
        "index.html",
        stats=stats,
        charities=charities,
        recent_txs=recent_txs,
        current_user=current_user,
        chain_health=chain_health
    )


@app.route("/donate", methods=["GET", "POST"])
def donate():
    """Donate page - public."""
    charities = contract.get_charities()

    if request.method == "POST":
        donor_name = request.form.get("donor_name", "").strip()
        charity_id = request.form.get("charity_id", "")
        amount = request.form.get("amount", "0")
        message = request.form.get("message", "")

        try:
            amount = float(amount)
        except ValueError:
            flash("❌ Please enter a valid amount.", "error")
            return render_template("donate.html", charities=charities)

        result = contract.donate(donor_name, charity_id, amount, message)

        if result["success"]:
            flash(f"✅ Donation successful! Tracking ID: {result['tx_hash'][:20]}...", "success")
            return redirect(url_for("track", tx_hash=result["tx_hash"]))
        else:
            flash(f"❌ {result['error']}", "error")

    return render_template("donate.html", charities=charities)


@app.route("/track")
def track():
    """Track donation - public."""
    tx_hash = request.args.get("tx_hash", "")
    tx = None
    if tx_hash:
        tx = contract.blockchain.find_transaction(tx_hash)
    all_txs = contract.blockchain.get_all_transactions()[::-1]

    return render_template("track.html", tx=tx, tx_hash=tx_hash, all_txs=all_txs)


@app.route("/explorer")
def explorer():
    """Blockchain explorer - public."""
    chain = contract.blockchain.to_dict()[::-1]
    is_valid = contract.blockchain.is_chain_valid()
    chain_health = contract.blockchain.get_chain_health()

    return render_template(
        "explorer.html",
        chain=chain,
        is_valid=is_valid,
        chain_health=chain_health
    )


# ── AUTHENTICATION ROUTES ─────────────────────────────────────

@app.route("/login", methods=["GET", "POST"])
@app.route("/web_login", methods=["GET", "POST"])
def web_login():
    """Login page."""
    current_user = get_current_user()
    if current_user:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        success, message, new_session = auth_manager.login(
            username,
            password,
            ip_address=request.remote_addr,
            user_agent=request.headers.get("User-Agent", "")
        )

        if success:
            session["session_id"] = new_session.session_id
            flash(f"✅ Welcome, {new_session.user.username}!", "success")
            
            # Redirect based on role
            if new_session.user.role == "admin":
                return redirect(url_for("admin"))
            else:
                return redirect(url_for("dashboard"))
        else:
            flash(f"❌ {message}", "error")

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """User registration."""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()

        # Validation
        if not all([username, email, password, confirm_password]):
            flash("❌ All fields are required.", "error")
            return render_template("register.html")

        if password != confirm_password:
            flash("❌ Passwords do not match.", "error")
            return render_template("register.html")

        if len(password) < 8:
            flash("❌ Password must be at least 8 characters.", "error")
            return render_template("register.html")

        success, message, user = auth_manager.register_user(username, email, password, "donor")

        if success:
            flash(f"✅ Registration successful! Please log in.", "success")
            return redirect(url_for("web_login"))
        else:
            flash(f"❌ {message}", "error")

    return render_template("register.html")


@app.route("/logout")
def logout():
    """Logout user."""
    session_id = session.get("session_id")
    if session_id:
        auth_manager.logout(session_id)
    session.clear()
    flash("✅ You have been logged out.", "success")
    return redirect(url_for("index"))


# ── AUTHENTICATED USER ROUTES ─────────────────────────────────

@app.route("/dashboard")
@login_required
def dashboard():
    """User dashboard - requires login."""
    current_user = get_current_user()
    stats = contract.get_stats()
    charities = contract.get_charities()

    return render_template(
        "dashboard.html",
        current_user=current_user,
        stats=stats,
        charities=charities
    )


# ── ADMIN ROUTES ──────────────────────────────────────────────

@app.route("/admin")
@admin_required
def admin():
    """Admin panel."""
    current_user = get_current_user()
    charities = contract.get_charities()
    beneficiaries = contract.get_beneficiaries()
    stats = contract.get_stats()
    chain_health = contract.blockchain.get_chain_health()

    return render_template(
        "admin.html",
        current_user=current_user,
        charities=charities,
        beneficiaries=beneficiaries,
        stats=stats,
        chain_health=chain_health
    )


@app.route("/admin/release", methods=["POST"])
@admin_required
def admin_release():
    """Release funds - admin only."""
    charity_id = request.form.get("charity_id")
    beneficiary_id = request.form.get("beneficiary_id")
    amount = request.form.get("amount", "0")

    try:
        amount = float(amount)
    except ValueError:
        flash("❌ Invalid amount.", "error")
        return redirect(url_for("admin"))

    result = contract.release_funds(charity_id, beneficiary_id, amount)
    if result["success"]:
        flash(f"✅ {result['message']} (Hash: {result['tx_hash'][:20]}...)", "success")
    else:
        flash(f"❌ {result['error']}", "error")

    return redirect(url_for("admin"))


@app.route("/admin/verify/<beneficiary_id>", methods=["POST"])
@admin_required
def admin_verify(beneficiary_id):
    """Verify beneficiary - admin only."""
    result = contract.verify_beneficiary(beneficiary_id)
    if result["success"]:
        flash(f"✅ {result['message']}", "success")
    else:
        flash(f"❌ {result['error']}", "error")

    return redirect(url_for("admin"))


@app.route("/admin/add_beneficiary", methods=["POST"])
@admin_required
def admin_add_beneficiary():
    """Add beneficiary - admin only."""
    name = request.form.get("name", "").strip()
    charity_id = request.form.get("charity_id", "")

    if not name:
        flash("❌ Name is required.", "error")
        return redirect(url_for("admin"))

    result = contract.add_beneficiary(name, charity_id)
    if result["success"]:
        flash(f"✅ Beneficiary added (ID: {result['beneficiary_id']})", "success")
    else:
        flash(f"❌ {result['error']}", "error")

    return redirect(url_for("admin"))


@app.route("/admin/users")
@admin_required
def admin_users():
    """User management - admin only."""
    current_user = get_current_user()
    all_users = auth_manager.get_all_users()
    audit_log = auth_manager.get_audit_log(limit=50)

    return render_template(
        "admin_users.html",
        current_user=current_user,
        all_users=all_users,
        audit_log=audit_log
    )


@app.route("/admin/deactivate_user/<user_id>", methods=["POST"])
@admin_required
def admin_deactivate_user(user_id):
    """Deactivate user - admin only."""
    success, message = auth_manager.deactivate_user(user_id)
    if success:
        flash(f"✅ {message}", "success")
    else:
        flash(f"❌ {message}", "error")

    return redirect(url_for("admin_users"))


# ── SETTINGS ROUTES ───────────────────────────────────────────

@app.route("/settings")
@login_required
def settings():
    """User settings."""
    current_user = get_current_user()
    return render_template("settings.html", current_user=current_user)


@app.route("/settings/change_password", methods=["POST"])
@login_required
def change_password():
    """Change password."""
    current_user = get_current_user()
    old_password = request.form.get("old_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")

    if new_password != confirm_password:
        flash("❌ New passwords do not match.", "error")
        return redirect(url_for("settings"))

    if len(new_password) < 8:
        flash("❌ Password must be at least 8 characters.", "error")
        return redirect(url_for("settings"))

    success, message = auth_manager.change_password(
        current_user.username,
        old_password,
        new_password
    )

    if success:
        flash(f"✅ {message}", "success")
    else:
        flash(f"❌ {message}", "error")

    return redirect(url_for("settings"))


# ── API ROUTES ────────────────────────────────────────────────

@app.route("/api/chain")
def api_chain():
    """Get blockchain data (JSON)."""
    return jsonify(contract.blockchain.to_dict())


@app.route("/api/stats")
def api_stats():
    """Get statistics (JSON)."""
    return jsonify(contract.get_stats())


@app.route("/api/chain_health")
def api_chain_health():
    """Get blockchain health (JSON)."""
    return jsonify(contract.blockchain.get_chain_health())


# ── ERROR HANDLERS ────────────────────────────────────────────

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return render_template("404.html"), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return render_template("500.html"), 500


# ── RUN SERVER ────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "="*60)
    print("🔗 Charity Blockchain Platform Starting...")
    print("="*60)
    print("\n📍 URL: http://127.0.0.1:8080")
    print("\n👤 Default Admin Login:")
    print("   Username: Admin")
    print("   Password: Admin@123")
    print("\n👤 Default Manager Login:")
    print("   Username: Charity_Manager")
    print("   Password: Manager@123")
    print("\n" + "="*60 + "\n")

    app.run(debug=True, port=8080, host="127.0.0.1")
