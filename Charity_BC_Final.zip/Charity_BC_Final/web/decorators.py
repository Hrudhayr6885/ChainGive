# ============================================================
# web/decorators.py — PERSON 2's file (Helper)
# Authentication Decorators and Utility Functions
# ============================================================

from functools import wraps
from flask import session, redirect, url_for, flash
from core.auth import auth_manager


def login_required(f):
    """Require user to be logged in."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        session_id = session.get("session_id")
        if not session_id:
            flash("Please log in to access this page.", "error")
            return redirect(url_for("web_login"))

        is_valid, user = auth_manager.verify_session(session_id)
        if not is_valid:
            flash("Your session has expired. Please log in again.", "error")
            session.clear()
            return redirect(url_for("web_login"))

        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """Require admin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        session_id = session.get("session_id")
        if not session_id:
            flash("Please log in to access this page.", "error")
            return redirect(url_for("web_login"))

        is_valid, user = auth_manager.verify_session(session_id)
        if not is_valid or user.role != "admin":
            flash("You don't have permission to access this page.", "error")
            return redirect(url_for("index"))

        return f(*args, **kwargs)
    return decorated_function


def charity_manager_required(f):
    """Require charity manager or admin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        session_id = session.get("session_id")
        if not session_id:
            flash("Please log in to access this page.", "error")
            return redirect(url_for("web_login"))

        is_valid, user = auth_manager.verify_session(session_id)
        if not is_valid or user.role not in ["admin", "charity_manager"]:
            flash("You don't have permission to access this page.", "error")
            return redirect(url_for("index"))

        return f(*args, **kwargs)
    return decorated_function


def get_current_user():
    """Get the currently logged-in user."""
    session_id = session.get("session_id")
    if not session_id:
        return None

    is_valid, user = auth_manager.verify_session(session_id)
    return user if is_valid else None
