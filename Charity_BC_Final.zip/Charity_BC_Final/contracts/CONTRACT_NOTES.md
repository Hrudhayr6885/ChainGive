# ============================================================
# CONTRACT_NOTES.md
# Smart Contract Reference Documentation
# ============================================================

## Overview

This file documents the Solidity smart contract implementation. It serves as a **reference** for the Python-based blockchain implementation used in this project.

**Important Note:** The `.sol` file is NOT directly imported into Python. Instead, the Python backend (`core/contract_logic.py`) implements equivalent logic in Python using the Blockchain and Consensus Engine.

---

## Why Solidity + Python?

### Dual Implementation Strategy:
1. **Python Backend** - Educational implementation showing core blockchain concepts
   - Easy to understand and modify
   - Great for learning
   - Runs locally without Ethereum

2. **Solidity Reference** - Shows production deployment
   - How this would run on Ethereum
   - Smart contract concepts
   - Gas optimization

---

## Smart Contract Structure

### 1. Data Structures

#### `Charity`
```solidity
struct Charity {
    string  name;           // Charity name
    address wallet;         // Ethereum wallet address
    bool    verified;       // Verification status
    uint256 balance;        // Balance in wei (1 ETH = 10^18 wei)
}
```

#### `Beneficiary`
```solidity
struct Beneficiary {
    string  name;           // Beneficiary name
    string  charityId;      // Associated charity ID
    bool    verified;       // Verification status (fraud check)
    uint256 fundsReceived;  // Total funds received (wei)
}
```

---

### 2. Key Functions

#### `donate()`
```solidity
function donate(
    string donorName,
    string charityId,
    string message
) external payable
```

**Purpose:** Record a donation to a charity
- Validates charity exists and is verified
- Updates charity balance
- Emits `DonationReceived` event
- Equivalent to Python: `contract.donate()`

**Python Equivalent:**
```python
result = contract.donate(donor_name, charity_id, amount, message)
```

---

#### `releaseFunds()`
```solidity
function releaseFunds(
    string charityId,
    string beneficiaryId,
    uint256 amount
) external onlyOwner
```

**Purpose:** Admin releases funds to verified beneficiary
- Only admin/owner can call
- Validates beneficiary is verified
- Transfers ETH to charity wallet
- Emits `FundsReleased` event
- Equivalent to Python: `contract.release_funds()`

**Security:** `onlyOwner` modifier ensures only admin access

---

#### `verifyBeneficiary()`
```solidity
function verifyBeneficiary(string beneficiaryId) external onlyOwner
```

**Purpose:** Mark beneficiary as verified (fraud check passed)
- Prevents fund release to unverified beneficiaries
- Emits `BeneficiaryVerified` event
- Admin-only operation

**Python Equivalent:**
```python
result = contract.verify_beneficiary(beneficiary_id)
```

---

#### `addBeneficiary()`
```solidity
function addBeneficiary(
    string name,
    string charityId
) external onlyOwner
```

**Purpose:** Register a new beneficiary (starts unverified)
- Creates new beneficiary ID
- Links to charity
- Requires admin verification before funds release
- Emits `BeneficiaryAdded` event

---

### 3. Events (Logging)

Events in Solidity are equivalent to **transactions in Python blockchain**:

```solidity
event DonationReceived(
    string  indexed charityId,
    string  charityName,
    address indexed donor,
    string  donorName,
    uint256 amount,
    string  message,
    string  status
);
```

- **indexed**: Searchable fields (up to 3 per event)
- Emitted when donation is made
- Replaces `blockchain.add_transaction()` in Ethereum version

---

## Comparison: Solidity vs Python Implementation

### Donations

**Solidity Version:**
```solidity
function donate(string donorName, string charityId, string message) external payable {
    require(charities[charityId].verified, "Charity not verified");
    charities[charityId].balance += msg.value;
    emit DonationReceived(...);
}
```

**Python Version:**
```python
def donate(self, donor_name, charity_id, amount, message=""):
    if charity_id not in self.charities:
        return {"success": False, "error": "Charity not found"}
    
    transaction = {...}
    tx_hash = self.blockchain.add_transaction(transaction)
    self.charities[charity_id]["balance"] += amount
    return {"success": True, "tx_hash": tx_hash}
```

---

## Data Mapping

### Charities
- **Solidity:** Stored in `mapping(string => Charity) charities`
- **Python:** Stored in `self.charities = {}`
- **Default:** C001, C002, C003

### Beneficiaries
- **Solidity:** Stored in `mapping(string => Beneficiary) beneficiaries`
- **Python:** Stored in `self.beneficiaries = {}`
- **Default:** B001, B002, B003

---

## Storage vs Blockchain

### Solidity (Real Blockchain)
```
State stored on-chain in contract storage
Every change costs gas
Data persists permanently on Ethereum
```

### Python (Educational)
```
State stored in memory + data.json
No gas cost
Data persists in file system
Blockchain ensures immutability
```

---

## Security Features

### 1. Access Control
- **Solidity:** `onlyOwner` modifier
- **Python:** `@admin_required` decorator

### 2. Verification Checks
- Beneficiary must be verified before fund release
- Both versions implement this

### 3. Balance Validation
- Can't release more funds than available
- Both versions check this

### 4. Fraud Detection
- **Solidity:** None (assumes all submissions valid)
- **Python:** Fraud detection engine in `core/consensus.py`

---

## Deployment Guide

If deploying to Ethereum:

1. **Compile Solidity:**
   ```bash
   solc --version
   solcjs smart_contract.sol --bin --abi --o ./bin
   ```

2. **Deploy with Truffle or Hardhat:**
   ```bash
   truffle migrate --network ropsten
   ```

3. **Interact with Web3.py:**
   ```python
   from web3 import Web3
   w3 = Web3(Web3.HTTPProvider('http://localhost:8545'))
   contract = w3.eth.contract(address=contract_address, abi=abi)
   tx_hash = contract.functions.donate(...).transact()
   ```

---

## Gas Estimation (Ethereum)

Approximate gas costs:
- **donate():** 50,000 - 100,000 gas (~$5-$20 at current rates)
- **releaseFunds():** 40,000 - 80,000 gas (~$4-$16)
- **verifyBeneficiary():** 20,000 - 40,000 gas (~$2-$8)
- **addBeneficiary():** 80,000 - 120,000 gas (~$8-$24)

---

## Future Enhancements

### Solidity
- [ ] ERC-20 token integration for stablecoins
- [ ] Multi-signature wallet for fund release
- [ ] Governance token for DAO-style decisions
- [ ] Oracle integration for real-world data
- [ ] Cross-chain bridge support

### Python
- [ ] Integration with real blockchain (Web3.py)
- [ ] Database instead of JSON file
- [ ] REST API improvements
- [ ] Frontend framework upgrade (React/Vue)
- [ ] Mobile app

---

## Testing

### Solidity Testing
```bash
# Using Truffle
truffle test

# Using Hardhat
npx hardhat test
```

### Python Testing
```bash
# Run Flask tests
pytest tests/

# Test blockchain validation
python -m pytest tests/test_blockchain.py -v
```

---

## References

- [Solidity Documentation](https://docs.soliditylang.org/)
- [Ethereum Smart Contracts](https://ethereum.org/en/developers/docs/smart-contracts/)
- [Web3.py Documentation](https://web3py.readthedocs.io/)
- [Truffle Documentation](https://www.trufflesuite.com/docs/truffle/overview)

---

## Contact

For questions about the smart contract implementation, see the demo guide in `README_DEMO.md`.

---

**Last Updated:** April 16, 2026
**Status:** Reference Implementation ✅
