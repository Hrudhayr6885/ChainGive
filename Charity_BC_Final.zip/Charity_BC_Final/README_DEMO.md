# ============================================================
# README_DEMO.md
# DEMO GUIDE FOR 3-PERSON TEAM
# ============================================================

## 🎯 Project Overview

**Charity Blockchain Platform** - A secure, transparent donation management system built on blockchain technology with advanced consensus mechanisms and role-based authentication.

---

## 📊 Team Structure & Demo Breakdown

### **PERSON 1: Blockchain & Smart Contract Developer**
**Focus:** Core blockchain logic, consensus algorithm, data integrity

#### Files Worked On:
- `core/blockchain.py` - Blockchain implementation with Proof-of-Work
- `core/consensus.py` - Byzantine Fault Tolerant consensus engine
- `core/contract_logic.py` - Smart contract business logic (donations, fund release)
- `contracts/smart_contract.sol` - Reference Solidity contract

#### Demo Points:
1. **Explain Blockchain Basics**
   - Show how blocks are created and linked
   - Demonstrate hash generation and Proof-of-Work mining
   - Navigate `/explorer` to show the chain structure

2. **Consensus Algorithm**
   - Explain Byzantine Fault Tolerance mechanism
   - Show validation of blocks and chain integrity
   - Demonstrate how the system detects tampering
   - Explain validator stakes and weighted consensus

3. **Fraud Detection**
   - Show how unusual donations are flagged
   - Demonstrate rate limiting on donations
   - Explain the Merkle tree transaction verification

4. **Live Demo:**
   ```
   python web/app.py
   Go to http://127.0.0.1:8080/explorer
   Make a donation and show new block creation
   Show transaction tracking in the blockchain
   ```

---

### **PERSON 2: Full-Stack Web Developer**
**Focus:** Flask backend, REST APIs, user interface routing

#### Files Worked On:
- `web/app.py` - Flask application with all routes
- `web/decorators.py` - Authentication decorators and middleware
- `templates/` - All HTML templates for the UI
- API endpoints for blockchain data

#### Demo Points:
1. **Web Application Architecture**
   - Show Flask routing structure
   - Explain request/response handling
   - Demonstrate template rendering

2. **Feature Walkthrough**
   - **Public Features:**
     - Home page with statistics
     - Donation form with validation
     - Transaction tracking page
     - Blockchain explorer
   
   - **Authenticated Features:**
     - User dashboard
     - Donation history
     - Settings and profile management

   - **Admin Features:**
     - Admin panel overview
     - User management interface
     - Beneficiary management

3. **Live Demo:**
   ```
   python web/app.py
   
   Show Public Features:
   - Go to http://127.0.0.1:8080
   - Fill donation form → Submit → Show tracking page
   
   Show Admin Features:
   - Go to /login
   - Login as Admin / Admin@123
   - Show admin dashboard
   - Release funds to beneficiary
   - Verify new beneficiary
   ```

---

### **PERSON 3: Security & Authentication Expert**
**Focus:** User authentication, authorization, encryption, access control

#### Files Worked On:
- `core/auth.py` - Complete authentication system
- Role-based access control implementation
- Password hashing and session management
- Audit logging

#### Demo Points:
1. **Authentication System**
   - Explain user registration process
   - Show password hashing with PBKDF2
   - Demonstrate session management
   - Explain token-based authentication

2. **Authorization & Roles**
   - **Admin:** Full system access
   - **Charity Manager:** Manage beneficiaries and donations
   - **Donor:** Make donations and track transactions
   - Show permission matrix

3. **Security Features**
   - Account lockout after failed attempts
   - Session expiry and timeout
   - Audit logging of all actions
   - IP address and User-Agent tracking

4. **Live Demo:**
   ```
   python web/app.py
   
   Feature 1: User Registration
   - Go to /register
   - Create new donor account
   - Show password validation requirements
   
   Feature 2: Login Security
   - Try login with wrong password 5 times
   - Show account lockout message
   - Wait 30 seconds and retry
   
   Feature 3: Role-Based Access
   - Login as Admin
   - Access /admin (works)
   - Access /admin/users (works)
   - Logout
   - Login as Donor
   - Try to access /admin (access denied)
   
   Feature 4: Audit Log
   - Login as Admin
   - Go to /admin/users
   - Show audit log with all login/logout events
   ```

---

## 🚀 How to Run the Full Demo

### **Step 1: Setup Environment**
```bash
cd /Users/hrudhayr/Downloads/Charity_BC_Final

# Install dependencies
pip install -r requirements.txt

# Run Flask app
python web/app.py
```

### **Step 2: Access the Application**
- **Main URL:** http://127.0.0.1:8080
- **Default Credentials:**
  - Admin: `Admin` / `Admin@123`
  - Manager: `Charity_Manager` / `Manager@123`

### **Step 3: Demo Sequence (20-30 minutes)**

**Introduction (2 min)**
- Brief overview of the project
- Explain the 3-person team roles

**PERSON 1's Demo (8 min)**
1. Navigate to `/explorer` showing blockchain structure
2. Explain consensus algorithm (slides/whiteboard)
3. Make a donation and show new block creation
4. Show chain validation and integrity check
5. Explain fraud detection mechanism

**PERSON 2's Demo (8 min)**
1. Show all public pages (Home, Donate, Track)
2. Show user dashboard after login
3. Show admin panel interface
4. Make a donation and show full flow
5. Demonstrate transaction tracking

**PERSON 3's Demo (8 min)**
1. Register a new user account
2. Show failed login security (attempt 5 failed logins)
3. Show role-based access control
4. Login as different roles and show permission differences
5. Show admin audit log with all events

**Q&A (4 min)**

---

## 📋 Default Test Data

### Charities
- **C001** - Feed the Hungry ($0.00)
- **C002** - Education for All ($0.00)
- **C003** - Health Aid Fund ($0.00)

### Beneficiaries
- **B001** - Ananya Sharma (Verified, C001)
- **B002** - Ravi Kumar (Verified, C002)
- **B003** - Priya Nair (Pending Verification, C003)

### Test Users
- **Admin** - Role: admin, Pass: Admin@123
- **Charity_Manager** - Role: charity_manager, Pass: Manager@123

---

## 🔐 Security Features Demonstrated

1. **Password Security**
   - PBKDF2 hashing with salt
   - Account lockout after 5 failed attempts
   - Minimum 8-character passwords

2. **Session Management**
   - 60-minute session timeout
   - Session refresh on activity
   - Secure session tokens

3. **Access Control**
   - Role-based permissions
   - Route protection with decorators
   - Feature-level access control

4. **Audit Trail**
   - All logins/logouts recorded
   - Action tracking
   - Timestamp and IP logging

---

## 🧪 Testing Scenarios

### Donation Flow Test
```
1. Go to /donate
2. Fill form: Donor Name, Select Charity, Amount, Message
3. Click Donate
4. Check tracking page with TX hash
5. Go to /explorer and verify new block
```

### Admin Operations Test
```
1. Login as Admin (Admin/Admin@123)
2. Go to /admin
3. Add a new beneficiary
4. Verify the beneficiary
5. Release funds from charity to beneficiary
6. Check /explorer to see fund release transaction
```

### Role-Based Access Test
```
1. Logout
2. Register as new user (automatically Donor role)
3. Try to access /admin (should be denied)
4. Try to access /donate (should work)
5. Logout and login as Admin
6. Access /admin (should work)
```

---

## 📁 Project Structure

```
Charity_BC_Final/
├── core/                          # PERSON 1: Blockchain Logic
│   ├── blockchain.py             # Block and chain implementation
│   ├── consensus.py              # Byzantine consensus engine
│   ├── contract_logic.py          # Smart contract logic
│   ├── auth.py                   # (PERSON 3) Auth system
│   └── __init__.py
│
├── web/                          # PERSON 2: Web Application
│   ├── app.py                    # Flask routes
│   ├── decorators.py             # Auth decorators
│   └── __init__.py
│
├── contracts/                    # Reference Solidity
│   ├── smart_contract.sol
│   └── CONTRACT_NOTES.md
│
├── templates/                    # HTML Templates
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── donate.html
│   ├── track.html
│   ├── explorer.html
│   ├── admin.html
│   ├── dashboard.html
│   ├── settings.html
│   ├── admin_users.html
│   ├── 404.html
│   └── 500.html
│
├── data.json                     # Persistent blockchain storage
├── requirements.txt              # Python dependencies
└── README_DEMO.md               # This file
```

---

## 🎓 Learning Outcomes

After this demo, observers will understand:

1. **Blockchain Technology**
   - How blocks are created and linked
   - Proof-of-Work consensus
   - Byzantine Fault Tolerance

2. **Web Development**
   - Flask application structure
   - RESTful API design
   - Template rendering and routing

3. **Security**
   - Authentication and authorization
   - Password hashing and session management
   - Role-based access control
   - Audit logging

4. **Real-World Applications**
   - How blockchain can be used for transparency
   - Fraud detection and prevention
   - Secure fund management

---

## ❓ FAQ for Q&A Session

**Q: Why not use a real blockchain like Ethereum?**
A: This implementation shows the core concepts clearly. In production, you'd use existing blockchains but with custom smart contracts.

**Q: How is this different from a regular database?**
A: Immutability - once recorded, transactions can't be modified without detection. Everyone can verify the chain.

**Q: Can the admin tamper with donations?**
A: No! The blockchain prevents this. Even admin can't modify past transactions. All actions are audited.

**Q: How scalable is this?**
A: For learning purposes, this handles hundreds of transactions. For production, you'd optimize consensus and use sharding.

**Q: What about privacy?**
A: Currently transparent. In production, you'd add encryption and zero-knowledge proofs.

---

## 📞 Support & Contact

For questions about specific components:
- **Blockchain Questions:** PERSON 1
- **Web Development Questions:** PERSON 2  
- **Security Questions:** PERSON 3

---

**Last Updated:** April 16, 2026
**Project Version:** 1.0.0
**Status:** Ready for Demo ✅
